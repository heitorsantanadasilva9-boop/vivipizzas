export interface MenuItem {
  id: string;
  name: string;
  description: string;
  priceSmall: number;
  priceLarge: number;
  highlight?: boolean;
  tag?: string;
  category: 'Salgadas' | 'Especiais' | 'Doces' | 'Bebidas';
  image: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Tudo' | 'Cardápio' | 'Vídeos' | 'Gastronomia' | 'Ambiente' | 'Pizza' | 'Do proprietário' | 'Street View e 360°';
  type: 'image' | 'video' | '360';
  url: string;
  author?: string;
  views?: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  date: string;
  text: string;
  likes: number;
  avatarColor: string;
}

export const LISTING_INFO = {
  name: "Vivi Pizzas",
  rating: 4.9,
  reviewCount: 28,
  priceRange: "R$ 20–40",
  priceInfoText: "R$ 20–40 por pessoa · Informado por 9 pessoas",
  category: "Pizzaria",
  address: "R. Anísio Teixeira - Centro, Coração de Maria - BA, 44250-000",
  plusCode: "Q723+8P Coração de Maria, Bahia",
  phone: "(75) 98226-2466",
  hours: "Aberto · Fecha 23:00",
  serviceOptions: ["Refeição no local", "Entrega"],
  appDownloadUrl: "#",
};

export const MENU_ITEMS: MenuItem[] = [
  {
    id: "calabresa",
    name: "Calabresa",
    description: "Molho de tomate artesanal, generosa camada de mussarela, linguiça calabresa defumada fatiada, cebola roxa e orégano fresco.",
    priceSmall: 24.00,
    priceLarge: 36.00,
    highlight: true,
    tag: "Mais pedido",
    category: "Salgadas",
    image: "/images/pizza-calabresa.jpg"
  },
  {
    id: "frango-catupiry-bacon",
    name: "Frango Com Catupiry E Bacon",
    description: "Frango desfiado temperado com ervas, autêntico Catupiry cremoso, tiras crocantes de bacon e azeitonas pretas selecionadas.",
    priceSmall: 28.00,
    priceLarge: 40.00,
    highlight: true,
    tag: "Mais pedido",
    category: "Especiais",
    image: "/images/pizza-destaque.jpg"
  },
  {
    id: "bacon-vida",
    name: "De Bacon A Vida",
    description: "A queridinha dos apaixonados por bacon! Mussarela derretida, parmesão ralado, muito bacon em cubos crocantes e toque de alho poró.",
    priceSmall: 28.00,
    priceLarge: 40.00,
    highlight: true,
    tag: "Exclusividade",
    category: "Especiais",
    image: "/images/pizza-destaque.jpg"
  },
  {
    id: "portuguesa",
    name: "Portuguesa Tradicional",
    description: "Mussarela, presunto magro, ovos cozidos, ervilhas frescas, cebola, azeitonas e pimentão.",
    priceSmall: 25.00,
    priceLarge: 37.00,
    category: "Salgadas",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "margherita",
    name: "Margherita Premium",
    description: "Mussarela de búfala, rodelas de tomate fresco, manjericão cultivado na região e azeite extra virgem.",
    priceSmall: 22.00,
    priceLarge: 34.00,
    category: "Salgadas",
    image: "https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "quatro-queijos",
    name: "Quatro Queijos Ouro",
    description: "Mussarela, provolone defumado, gorgonzola suave e delicioso requeijão cremoso.",
    priceSmall: 27.00,
    priceLarge: 39.00,
    category: "Especiais",
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "doce-sensacao",
    name: "Sensação de Morango",
    description: "Chocolate ao leite derretido coberto com fatias frescas de morango e leite condensado.",
    priceSmall: 26.00,
    priceLarge: 38.00,
    category: "Doces",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "refrigerantes",
    name: "Refrigerante 1L / 2L",
    description: "Coca-Cola, Guaraná Antarctica ou Fanta geladíssima para acompanhar sua pizza.",
    priceSmall: 8.00,
    priceLarge: 12.00,
    category: "Bebidas",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=600&q=80"
  }
];

export const PEAK_HOURS = {
  description: "Horários de pico aos Sábados (baseado em visitas reais)",
  slots: [
    { time: "06:00", level: 5, label: "Tranquilo", percent: 10 },
    { time: "09:00", level: 15, label: "Tranquilo", percent: 15 },
    { time: "12:00", level: 45, label: "Movimento moderado", percent: 45 },
    { time: "15:00", level: 30, label: "Tranquilo", percent: 30 },
    { time: "18:00", level: 85, label: "Muito movimentado", percent: 85 },
    { time: "21:00", level: 100, label: "Pico de pedidos", percent: 100 },
    { time: "23:00", level: 40, label: "Fechando", percent: 40 },
  ],
  otherDays: {
    "Domingo": [20, 30, 60, 40, 90, 80, 20],
    "Segunda-feira": [5, 10, 30, 20, 50, 40, 10],
    "Terça-feira": [5, 15, 35, 25, 60, 50, 15],
    "Quarta-feira": [10, 20, 40, 30, 70, 65, 20],
    "Quinta-feira": [10, 25, 50, 30, 75, 70, 25],
    "Sexta-feira": [15, 30, 55, 40, 95, 90, 35],
  }
};

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "g1",
    title: "Frango com Catupiry e Bacon saindo do forno",
    category: "Pizza",
    type: "image",
    url: "/images/pizza-destaque.jpg",
    author: "Do proprietário",
    views: "1.4k visualizações"
  },
  {
    id: "g2",
    title: "Nosso ambiente aconchegante à noite",
    category: "Ambiente",
    type: "image",
    url: "/images/ambiente-vivi.jpg",
    author: "Do proprietário",
    views: "980 visualizações"
  },
  {
    id: "g3",
    title: "Clássica Pizza de Calabresa Fatiada",
    category: "Pizza",
    type: "image",
    url: "/images/pizza-calabresa.jpg",
    author: "Cliente: Mariana S.",
    views: "542 visualizações"
  },
  {
    id: "g4",
    title: "Preparação artesanal da massa",
    category: "Gastronomia",
    type: "video",
    url: "https://images.unsplash.com/photo-1590947132387-155cc02f3212?auto=format&fit=crop&w=800&q=80",
    author: "Do proprietário",
    views: "2.1k visualizações"
  },
  {
    id: "g5",
    title: "Cardápio Físico Atualizado",
    category: "Cardápio",
    type: "image",
    url: "https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&w=800&q=80",
    author: "Do proprietário",
    views: "3.5k visualizações"
  },
  {
    id: "g6",
    title: "Fachada e Vista Interativa 360° - R. Anísio Teixeira",
    category: "Street View e 360°",
    type: "360",
    url: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
    author: "Google Street View",
    views: "4.8k visualizações"
  },
  {
    id: "g7",
    title: "De Bacon a Vida com borda dourada",
    category: "Gastronomia",
    type: "image",
    url: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=800&q=80",
    author: "Cliente: Roberto M.",
    views: "710 visualizações"
  },
  {
    id: "g8",
    title: "Vídeo do queijo esticando irresistível",
    category: "Vídeos",
    type: "video",
    url: "https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=800&q=80",
    author: "Cliente: Aline F.",
    views: "1.9k visualizações"
  }
];

export const INITIAL_REVIEWS: ReviewItem[] = [
  {
    id: "r1",
    author: "Carlos Eduardo Silva",
    rating: 5,
    date: "Há 3 dias",
    text: "Melhor pizza de Coração de Maria disparado! A 'De Bacon A Vida' é espetacular. O atendimento via WhatsApp foi super rápido e a pizza chegou fumegando em casa. Preço muito justo de R$ 30 por pessoa.",
    likes: 12,
    avatarColor: "bg-red-600"
  },
  {
    id: "r2",
    author: "Juliana Mendes",
    rating: 5,
    date: "Há 1 semana",
    text: "Ambiente muito agradável no centro da cidade. Pedi a Frango com Catupiry e Bacon e a massa é fina, crocante, com recheio de verdade, não economizam! Nota 1000.",
    likes: 8,
    avatarColor: "bg-amber-500"
  },
  {
    id: "r3",
    author: "Marcos Vinicius",
    rating: 5,
    date: "Há 2 semanas",
    text: "Atendimento excelente, cerveja bem gelada e a pizza sai bem rápido. O preço médio fica entre 20 e 40 reais dependendo do tamanho. Recomendo muito aos sábados à noite!",
    likes: 5,
    avatarColor: "bg-emerald-600"
  },
  {
    id: "r4",
    author: "Beatriz Nogueira",
    rating: 4,
    date: "Há 3 semanas",
    text: "Muito gostosa a pizza de Calabresa. Apenas o local fica bastante cheio por volta das 21h no sábado, então vale a pena pedir para entrega se não quiser esperar mesa. Recomendo baixar o app deles para cupons.",
    likes: 3,
    avatarColor: "bg-blue-600"
  },
  {
    id: "r5",
    author: "Roberto Dantas",
    rating: 5,
    date: "Há 1 mês",
    text: "Fantástica! Ingredientes frescos e o Plus Code Q723+8P nos guiou perfeitamente pelo Google Maps. Estão de parabéns, o dono sempre atencioso.",
    likes: 7,
    avatarColor: "bg-purple-600"
  }
];

export const GOOGLE_MAPS_RATINGS_SUMMARY = {
  total: 28,
  average: 4.9,
  distribution: [
    { stars: 5, count: 26 },
    { stars: 4, count: 2 },
    { stars: 3, count: 0 },
    { stars: 2, count: 0 },
    { stars: 1, count: 0 },
  ]
};
