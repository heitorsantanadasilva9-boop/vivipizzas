import React, { useState } from 'react';
import { Clock, Users, Calendar, AlertTriangle, Check } from 'lucide-react';
import { PEAK_HOURS } from '../data/viviData';

export const PeakHoursWidget: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState<string>('Sábado');
  const [activeSlotIndex, setActiveSlotIndex] = useState<number>(5); // default 21:00 (Pico)
  const [reservationName, setReservationName] = useState<string>('');
  const [reservationPeople, setReservationPeople] = useState<number>(2);
  const [booked, setBooked] = useState<boolean>(false);

  const days = ['Sábado', 'Domingo', 'Sexta-feira', 'Quinta-feira', 'Quarta-feira', 'Terça-feira', 'Segunda-feira'];

  const currentSlots = selectedDay === 'Sábado' 
    ? PEAK_HOURS.slots 
    : PEAK_HOURS.slots.map((s, idx) => ({
        ...s,
        level: (PEAK_HOURS.otherDays as Record<string, number[]>)[selectedDay]?.[idx] || 30,
        label: ((PEAK_HOURS.otherDays as Record<string, number[]>)[selectedDay]?.[idx] || 30) > 70 
          ? 'Muito movimentado' 
          : 'Tranquilo'
      }));

  const activeSlot = currentSlots[activeSlotIndex] || currentSlots[0];

  const handleBookSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (reservationName.trim()) {
      setBooked(true);
      setTimeout(() => {
        setBooked(false);
        setReservationName('');
      }, 5000);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-stone-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-stone-100">
        <div>
          <div className="flex items-center gap-2 text-stone-900 font-bold text-lg">
            <Clock className="w-5 h-5 text-amber-500" />
            <h3>Horários de pico e Movimento</h3>
          </div>
          <p className="text-stone-500 text-xs mt-0.5">
            Dados fornecidos pelo Google Maps em tempo real · {PEAK_HOURS.description}
          </p>
        </div>

        {/* Day Selector dropdown / chips */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs font-medium text-stone-400 mr-1 whitespace-nowrap">Dia:</span>
          <select 
            value={selectedDay}
            onChange={(e) => {
              setSelectedDay(e.target.value);
              setActiveSlotIndex(5); // reset to peak
            }}
            className="bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold py-1.5 px-3 rounded-lg border-0 focus:ring-2 focus:ring-amber-400 cursor-pointer transition-colors"
          >
            {days.map(d => (
              <option key={d} value={d}>
                {d === 'Sábado' ? '🔥 Sábado (Principal)' : d}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Interactive Bar Chart exactly mimicking Google Maps with slots: 06, 09, 12, 15, 18, 21 */}
      <div className="mt-6">
        <div className="text-center mb-2">
          <span className="bg-amber-100 text-amber-900 text-[11px] font-bold px-2.5 py-1 rounded-full inline-block">
            {selectedDay}: {activeSlot.time} — <strong className="text-red-700">{activeSlot.label}</strong> ({activeSlot.level}% de ocupação)
          </span>
        </div>

        {/* Beautiful Interactive Chart */}
        <div className="h-40 flex items-end justify-between gap-1 sm:gap-3 pt-8 px-2 bg-stone-50 rounded-xl border border-stone-100 relative">
          
          {/* Background guide lines */}
          <div className="absolute inset-x-0 top-1/4 border-b border-stone-200/60 text-[9px] text-stone-400 px-2 flex justify-between pointer-events-none">
            <span>Pico máximo</span>
            <span>Geralmente espera de 15-25 min</span>
          </div>
          <div className="absolute inset-x-0 top-2/4 border-b border-stone-200/60 text-[9px] text-stone-400 px-2 pointer-events-none">
            <span>Movimento moderado</span>
          </div>

          {currentSlots.map((slot, idx) => {
            const isSelected = activeSlotIndex === idx;
            const isPeakHour = slot.time === '21:00' || slot.time === '18:00';

            return (
              <button
                key={slot.time}
                type="button"
                onClick={() => setActiveSlotIndex(idx)}
                className="flex-1 flex flex-col items-center justify-end h-full group cursor-pointer focus:outline-none relative z-10"
                title={`Clique para selecionar ${slot.time} - ${slot.label}`}
              >
                {/* Floating tooltip preview */}
                <span className={`absolute -top-7 bg-stone-900 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-20 ${isSelected ? 'opacity-100 bg-amber-600' : ''}`}>
                  {slot.level}%
                </span>

                {/* The Bar */}
                <div className="w-full max-w-[36px] bg-stone-200 rounded-t-md relative transition-all duration-500 flex items-end justify-center" style={{ height: `${Math.max(slot.level, 8)}%` }}>
                  
                  {/* Fill color based on intensity and selection */}
                  <div 
                    className={`w-full rounded-t-md transition-all duration-300 ${
                      isSelected 
                        ? 'bg-gradient-to-t from-red-600 to-amber-500 shadow-md' 
                        : isPeakHour 
                          ? 'bg-amber-400 group-hover:bg-amber-500' 
                          : 'bg-stone-300 group-hover:bg-stone-400'
                    }`}
                    style={{ height: '100%' }}
                  />

                  {/* Tiny peak star indicator */}
                  {isPeakHour && !isSelected && (
                    <span className="absolute -top-3 text-[8px] block text-amber-600 font-bold">⭐</span>
                  )}
                </div>

                {/* Exact time label from the listing: 06, 09, 12, 15, 18, 21 */}
                <span className={`text-[11px] font-bold mt-2 block transition-colors ${isSelected ? 'text-red-600 font-extrabold scale-110' : 'text-stone-600'}`}>
                  {slot.time.split(':')[0]}h
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex justify-between items-center text-[10px] text-stone-400 px-2 mt-1">
          <span>Manhã (06h)</span>
          <span>Almoço (12h)</span>
          <span>Tarde (15h)</span>
          <span>Noite / Jantar (18h - 21h)</span>
        </div>
      </div>

      {/* Reservation & Wait Time Estimator bound to active slot */}
      <div className="mt-5 bg-stone-50 rounded-xl p-3 sm:p-4 border border-stone-200/80">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-stone-800 font-bold">
              <Users className="w-3.5 h-3.5 text-stone-600" />
              <span>Previsão para {selectedDay} às {activeSlot.time}:</span>
            </div>
            
            <div className="text-xs text-stone-600 flex flex-wrap items-center gap-2">
              {activeSlot.level > 70 ? (
                <>
                  <span className="text-amber-700 font-medium flex items-center gap-1 bg-amber-100/80 px-2 py-0.5 rounded">
                    <AlertTriangle className="w-3 h-3" />
                    Mesas concorridas
                  </span>
                  <span>Tempo de preparo: <strong>25 - 35 min</strong></span>
                </>
              ) : (
                <>
                  <span className="text-emerald-700 font-medium flex items-center gap-1 bg-emerald-100/80 px-2 py-0.5 rounded">
                    <Check className="w-3 h-3" />
                    Mesas livres disponíveis
                  </span>
                  <span>Tempo de preparo: <strong>10 - 15 min</strong> (Rápido)</span>
                </>
              )}
            </div>
            <p className="text-[11px] text-stone-400">
              *Aberto das 18:00 até 23:00 para pizzas quentinhas. Dica: reserve com antecedência.
            </p>
          </div>

          {/* Quick Reservation Form */}
          <form onSubmit={handleBookSlot} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 bg-white p-2 rounded-lg border border-stone-200 shadow-2xs w-full md:w-auto">
            <input 
              type="text" 
              required
              placeholder="Seu Nome..." 
              value={reservationName}
              onChange={(e) => setReservationName(e.target.value)}
              className="text-xs px-2 py-1.5 border border-stone-200 rounded focus:outline-none focus:border-amber-500 w-full sm:w-28 text-stone-800 placeholder:text-stone-400"
            />
            
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-stone-400 whitespace-nowrap pl-1">Pessoas:</span>
              <select 
                value={reservationPeople}
                onChange={(e) => setReservationPeople(Number(e.target.value))}
                className="text-xs bg-stone-50 border border-stone-200 rounded p-1 text-stone-800"
              >
                {[1, 2, 3, 4, 5, 6, 8, 10, 12].map(num => (
                  <option key={num} value={num}>{num} p.</option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-1.5 px-3 rounded transition-colors whitespace-nowrap flex items-center justify-center gap-1 cursor-pointer"
            >
              <Calendar className="w-3 h-3" />
              <span>Reservar {activeSlot.time}</span>
            </button>
          </form>

        </div>

        {booked && (
          <div className="mt-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs p-2.5 rounded-lg text-center font-medium animate-fade-in flex items-center justify-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 bg-emerald-100 rounded-full p-0.5" />
            <span>
              Reserva de mesa e prioridade de forno confirmada para <strong>{reservationName}</strong> ({reservationPeople} pessoas) no {selectedDay} às {activeSlot.time}! O código do Google Maps foi vinculado à sua mesa.
            </span>
          </div>
        )}

      </div>
    </div>
  );
};
